
package JavaAssignment1;

import java.util.Scanner;

public class SecondQuestion {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size :");
		int n=sc.nextInt();
		for(int i=1;i<n;i++) {
			for(int j=0;j<n;j++) {
				System.out.print(i);
			}
			System.out.println();
		}
	}

}
