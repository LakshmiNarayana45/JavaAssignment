package JavaAssignment1;

public class FourthQuestion {

	public static void main(String[] args) {
		
		int n =7;
		for(int i=0;i<n;i++) {
			for(int j=0;j<n;j++) {
				if(n<=10) {
				if(j==0&&i!=0&&i!=1&&i!=2||j==(n-1)&&i!=0&&i!=1&&i!=2||i==(n-1)||i-j>=(n-1)/2||i+j>=((n-1)+(n-1)/2)) {
					System.out.print("*");
				}else {
					System.out.print(" ");
				}
				}
			}
			System.out.println();
		}

	}

}
